/*!
* Start Bootstrap - Shop Homepage v5.0.6 (https://startbootstrap.com/template/shop-homepage)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-shop-homepage/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project

document.addEventListener("DOMContentLoaded", () => {
    const carrito = [];
    const contenedorCarrito = document.createElement("div");
    contenedorCarrito.id = "carrito";
    contenedorCarrito.style.position = "fixed";
    contenedorCarrito.style.top = "80px";
    contenedorCarrito.style.right = "20px";
    contenedorCarrito.style.width = "300px";
    contenedorCarrito.style.background = "#fff";
    contenedorCarrito.style.border = "1px solid #ccc";
    contenedorCarrito.style.padding = "15px";
    contenedorCarrito.style.zIndex = "9999";
    contenedorCarrito.style.display = "none";
    contenedorCarrito.style.maxHeight = "70vh";
    contenedorCarrito.style.overflowY = "auto";
    document.body.appendChild(contenedorCarrito);

    const botonCarrito = document.getElementById("btn-ver-carrito");
    const contadorCarrito = botonCarrito.querySelector("span");

    // Mostrar/ocultar carrito
    botonCarrito.addEventListener("click", () => {
        contenedorCarrito.style.display =
            contenedorCarrito.style.display === "none" ? "block" : "none";
    });

    // Botones de "Añadir al Carrito"
    const botonesAgregar = document.querySelectorAll(".card-footer a");
    botonesAgregar.forEach((btn) => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const producto = e.target.closest(".card");
            const nombre = producto.querySelector("h5").textContent;
            const precioTexto = producto.querySelector(".text-center").innerText.match(/\$[\d\.]+/g);
            const precio = precioTexto ? parseFloat(precioTexto.slice(-1)[0].replace("$", "")) : 0;

            const existente = carrito.find(item => item.nombre === nombre);
            if (existente) {
                existente.cantidad += 1;
            } else {
                carrito.push({ nombre, precio, cantidad: 1 });
            }

            actualizarCarrito();
        });
    });

    function actualizarCarrito() {
        contenedorCarrito.innerHTML = "<h5>Carrito de compras</h5>";
        let total = 0;

        if (carrito.length === 0) {
            contenedorCarrito.innerHTML += "<p>El carrito está vacío.</p>";
        } else {
            carrito.forEach((item, index) => {
                const itemDiv = document.createElement("div");
                itemDiv.style.display = "flex";
                itemDiv.style.justifyContent = "space-between";
                itemDiv.style.alignItems = "center";
                itemDiv.style.marginBottom = "8px";

                itemDiv.innerHTML = `
                    <span>${item.nombre} (x${item.cantidad}) - $${(item.precio * item.cantidad).toFixed(2)}</span>
                    <button class="btn btn-sm btn-danger" data-index="${index}">X</button>
                `;

                contenedorCarrito.appendChild(itemDiv);
                total += item.precio * item.cantidad;
            });

            const totalDiv = document.createElement("p");
            totalDiv.innerHTML = `<strong>Total: $${total.toFixed(2)}</strong>`;
            contenedorCarrito.appendChild(totalDiv);

            const vaciarBtn = document.createElement("button");
            vaciarBtn.className = "btn btn-outline-danger btn-sm mt-2";
            vaciarBtn.textContent = "Vaciar carrito";
            vaciarBtn.addEventListener("click", () => {
                carrito.length = 0;
                actualizarCarrito();
            });
            contenedorCarrito.appendChild(vaciarBtn);
        }

        contadorCarrito.textContent = carrito.reduce((acc, item) => acc + item.cantidad, 0);

        // Eliminar producto específico
        contenedorCarrito.querySelectorAll("button[data-index]").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const index = parseInt(e.target.getAttribute("data-index"));
                carrito.splice(index, 1);
                actualizarCarrito();
            });
        });
    }
});
